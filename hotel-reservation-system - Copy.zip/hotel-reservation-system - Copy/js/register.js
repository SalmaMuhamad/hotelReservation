
$(document).ready(function () {
    $("#bookRoomBtn").click(function () {
        $("#bookRest").slideUp("slow", function () {
            $("#bookHall").slideUp("slow", function () {
                $("#bookRoom").slideDown("slow");
            });
        });
    });
});


$(document).ready(function () {
    $("#bookRestBtn").click(function () {
        $("#bookHall").slideUp("slow", function () {
            $("#bookRoom").slideUp("slow", function () {
                $("#bookRest").slideDown("slow.");
            });
        });
    });
});


$(document).ready(function () {
    $("#bookHallBtn").click(function () {
        $("#bookRoom").slideUp("slow", function () {
            $("#bookRest").slideUp("slow", function () {
                $("#bookHall").slideDown("slow.");
            });
        });
    });
});
